<div class="container">
    <div class="row">
        <div class="col-xs-12 col-sm col-md-4">
            <div class="padding">
                <h5 class="uppercase">Assine a newsletter do logo</h5>
                <div class="row input-btn between-xs" id="cep">
                    <input type="email" name="email" class="font2" placeholder="Seu e-mail"/>
                    <a href="" class="btn">Enviar</a>
                </div>
            </div>
        </div>
        <div class="col-xs-12 col-sm col-md-offset-2">
            <div class="padding">
                <h5 class="uppercase">Siga as lojas logo nas redes sociais</h5>
                <div class="row center-xs" id="redes-sociais">
                    <div><a href="" class="btn"><i class="fa fa-2x fa-facebook"></i></a></div>
                    <div><a href="" class="btn"><i class="fa fa-2x fa-youtube-play"></i></a></div>
                    <div><a href="" class="btn"><i class="fa fa-2x fa-instagram"></i></a></div>
                </div>
            </div>
        </div>
    </div>
</div>