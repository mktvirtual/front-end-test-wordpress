<div id="apoio">
    <div class="container-fluid">
        <div class="row middle-xs end-xs">
                <div class="col-lg-8 col-xs">
                    <ul class="menu middle-xs">
                        <li class="hidden-xs"><a href="#">Peça seu cartão de cliente</a></li>
                        <li class="hidden-xs">
                            <a href="#">
                                <i class="fa fa-barcode fa-lg"></i>
                                Solicite a 2ª via do boleto</a></li>
                        <li class="hidden-xs"><a href="#">Encontre uma loja</a></li>
                        <li class="hidden-xs"><a href="#">Assine a newsletter</a></li>
                    </ul>
                </div>
                <div class="hidden-xs hidden-sm hidden-md col-xs">
                    <div class="busca row">
                            <input type="text" placeholder="Busca" name="busca"/>
                            <a href="#" class="submit">
                                <i class="fa fa-lg fa-search" aria-hidden="true"></i>
                            </a>
                    </div>
                </div>
                <div id="mini-busca">
                    <div class="row middle-xs">
                        <input type="text" placeholder="Busca">
                        <i class="fa fa-lg fa-search" aria-hidden="true"></i>
                    </div>
                </div>
        </div>
    </div>
</div>