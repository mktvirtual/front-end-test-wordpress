
    <div class="footer">
      <div class="container row redessociais">
      	<i class="fa fa-facebook fa-lg"></i>
      	<i class="fa fa-twitter fa-lg"></i>
		<i class="fa fa-instagram fa-lg"></i>
		<span class="fa-stack fa-lg">
		  <i class="fa fa-circle fa-stack-2x"></i>
		  <i class="fa fa-youtube fa-stack-1x"></i>
		</span>
		<i class="fa fa-rss fa-lg"></i>
      </div>
    </div>



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
  </body>
</html>