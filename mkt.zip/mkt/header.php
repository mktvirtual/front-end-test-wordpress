<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>mkt virtual</title>
    <link href="<?php bloginfo('template_directory'); ?>/style.css" rel="stylesheet">
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">    
  </head>

  <body data-spy="scroll" data-target=".dinamo">

    <div class="navbar navbar-default navbar-fixed-top" role="navigation">
      <div class="container">
        <div class="row">
          <img class="logo-brand" src="http://localhost/wordpress/wp-content/themes/mkt/imagens/logo.png" style="width: 190px; height: 52px;">
        </div>  
        <div class="row">        
          <div class="dinamo">
            <ul class="nav navbar-nav">
              <li><a href="#lorem">LOREM</a></li>
              <li><a href="#ipsum">IPSUM DOLOR</a></li>
              <li><a href="#sit">SIT AMET</a></li>
              <li><a href="#mauris">MAURIS</a></li>
              <li><a href="#neque">NEQUE NULLA</a></li>
              <li><a href="#bibendum">BIBENDUM</a></li>
              <li><a href="#congedom">CONGEDOM MAURIS</a></li>
            </ul>
          </div>
        </div>  
      </div>
    </div>