<?php get_header();?>

    <div class="container">

      <div class="row first">
    <?php query_posts( 'category_name=destaques&posts_per_page=1' ); ?>
    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
        <div class="col-md-4 maxpost">          
          <div class="maxbox">
            <h2><?php $category = get_the_category(); echo $category[1]->cat_name;?></h2>
            <p><?php the_title(); ?></p>
          </div>
        </div>      
        <div class="col-md-8 medpost agua">
          <div class="medbox">
            <h2><?php $category = get_the_category(); echo $category[1]->cat_name;?></h2>
            <p><?php the_title(); ?></p>
          </div>
        </div>
      <?php endwhile;?>
    <?php endif; ?>

      </div>

      <div class="row">
    <?php query_posts( 'category_name=destaques&posts_per_page=1' ); ?>
    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
        <div class="col-md-8 medpost agua">
          <div class="medbox">
            <h2><?php $category = get_the_category(); echo $category[1]->cat_name;?></h2>
            <p><?php the_title(); ?></p>
          </div>
        </div>
        <div class="col-md-4 maxpost amarelo">
          <div class="maxbox">
            <h2><?php $category = get_the_category(); echo $category[1]->cat_name;?></h2>
            <p><?php the_title(); ?></p>
          </div>
        </div>
      <?php endwhile;?>
    <?php endif; ?>
      </div>


      <div class="row"><!--ultimas-->
        <h1>ÚLTIMAS</h1>
          <?php query_posts( 'posts_per_page=4' ); 
          ?>
          <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?> 
            <div class="col-md-3 minipost">
                    <img src="#" class="agua"/>
                    <h3><?php $category = get_the_category(); echo $category[0]->cat_name;?></h3>
                    <p><?php the_title(); ?></p>
                    <p class="data_post"><?php the_time('F j, Y'); ?></p>
                  </div>
          <?php endwhile; ?>
          <?php endif; ?>          
      </div>

      <div class="row"><!--lorem-->
        <h1 id="lorem">LOREM</h1> 
          <?php query_posts( 'category_name=lorem&posts_per_page=4' ); ?>        
          <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?> 
            <div class="col-md-3 minipost">
                    <img src="#" class="agua"/>
                    <p><?php the_title(); ?></p>
                    <p class="data_post"><?php the_time('j F'); ?> de <?php the_time('Y'); ?> </p>
                  </div>
          <?php endwhile; ?>
          <?php endif; ?>           
      </div>

      <div class="row"><!--ipsum-->
        <h1 id="ipsum">IPSUM</h1>
          <?php query_posts( 'category_name=ipsum&posts_per_page=4' ); ?>        
          <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?> 
            <div class="col-md-3 minipost">
                    <img src="#" class="agua"/>
                    <p><?php the_title(); ?></p>
                    <p class="data_post"><?php the_time('F j, Y'); ?></p>
                  </div>
          <?php endwhile; ?>
          <?php endif; ?> 
      </div>

    </div>
<?php get_footer();?>