        <div class="clearfix"></div>

        <div class="bg-gray">
            <div class="wrap">
                <footer class="footer">
                    <a href="javascript:void(0)" class="first social sprites-facebook" target="_blank"></a>
                    <a href="javascript:void(0)" class="social sprites-twitter" target="_blank"></a>
                    <a href="javascript:void(0)" class="social sprites-instagram" target="_blank"></a>
                    <a href="javascript:void(0)" class="social sprites-youtube" target="_blank"></a>
                    <a href="javascript:void(0)" class="social sprites-rss" target="_blank"></a>

                    <a href="http://www.mktvirtual.com.br/" class="signature sprites-mkt-signature" target="_blank"></a>
                </footer>
            </div>
        </div>

        <script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
        <script src="<?php bloginfo('template_url'); ?>/app/js/main.min.js"></script>

    </body>
</html>