<div class="newsletter">

				<h3>Assine nossa newsletter!</h3>
				<h2>Fique por dentro das novidades do site e de Magic the Gathering</h2>
				<form>
					<input type="email" name="buscar" placeholder="Email">
					<button>Assinar</button>
				</form>
				<div class="icones">
					<a href="#"><img src="http://localhost:8080/wordpress/wp-content/uploads/2016/02/twitter.png"></a>
					<a href="#"><img src="http://localhost:8080/wordpress/wp-content/uploads/2016/02/facebook.png"></a>
					<a href="#"><img src="http://localhost:8080/wordpress/wp-content/uploads/2016/02/google.png"></a>
				</div>


			</div>
			
			<div class="rodape">

				<p>Desenvolvido por Vitor Hugo Borges Yugulis. Todas as imagens pertencem a Wizards of the Coast, apenas as usei para um teste sem fins lucrativos.</p>

			</div>
</body>

</html>