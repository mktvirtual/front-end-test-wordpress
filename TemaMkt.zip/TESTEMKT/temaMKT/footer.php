<footer>
	<div id="map_canvas"></div>
	<div class="newsletter">

		<section class="nws-email">

			<h1>Assine a newsletter da Logo</h1>
			<form><input type="text" value="Seu e-mail" id="nws-email"></form>

		</section>
		<section class="icones">
			<h1>Siga a LOGO nas redes sociais</h1>
			<a href="#"><img src="http://localhost:8080/wordpress/wp-content/uploads/2016/03/facebook.png"></a>
			<a href="#"><img src="http://localhost:8080/wordpress/wp-content/uploads/2016/03/youtube.png"></a>
			<a href="#"><img src="http://localhost:8080/wordpress/wp-content/uploads/2016/03/instagram.png"></a>
		</section>

	</div>

	<!--FOOTER  *************************************************************************************************************************
	************************************************************************************************************************************-->
	<div class="footer">
		<article class="footer-corpo">

			<section class="footer-esquerdo">

				<ul>
					<h2>LOJAS LOGO</h2>
					<li><a href="#">Sobre</a></li>
					<li><a href="#">Lojas</a></li>
					<li><a href="#">Trabalhe conosco</a></li>
					<li><a href="#">Contato</a></li>
				</ul>

			</section>

			<section class="footer-central">
				
				<ul>
					<h2>LISTA DE ATALHOS</h2>
					<li><a href="#">Portal do colaborador</a></li>
					<li><a href="#">Promoções</a></li>
					<li><a href="#">Cartão do cliente</a></li>
					<li><a href="#">Cadastre-se</a></li>
					<li><a href="#">Blog</a></li>

				</ul>
			</section>

			<section class="footer-direito">
				<h2>SAC LOJA LOGO</h2>
				<h2>0800 701 0516</h2>
				<a href="#"><i class="fa fa-barcode"></i> &nbsp;Imprimir 2º via do boleto</a>
			</section>

			<section class="footer-inferior">
				2016, Lojas LOGO. Todos os direitos reservados.
			</section>
		</article>

	</div>

	<!--FOOTER mobile *************************************************************************************************************************
	************************************************************************************************************************************-->

	<div class="footermobile">

		<ul class="footer-lista">

			<li>
				<h2>SAC LOJA LOGO</h2>
				<h2>9999-9999</h2>
			</li>
			<li id="boleto"><a href="#"><i class="fa fa-barcode"></i> &nbsp;Imprimir 2º via do boleto</a></li>
			<li><a href="#"><h3>2016, Lojas Logo. Todos os direitos reservados.</h3></a></li>

		</ul>

	</div>

</footer>


</body>

</html>