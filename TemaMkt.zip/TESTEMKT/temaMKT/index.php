<?php get_header(); ?>

<main class="main">
	<section class="conteudo-superior">
		<aside><img src="http://localhost:8080/wordpress/wp-content/uploads/2016/03/aside.jpg"></aside>
			<article class="artigo1"><img src="http://localhost:8080/wordpress/wp-content/uploads/2016/03/img1.jpg"></article>
			<article class="artigo2"><img src="http://localhost:8080/wordpress/wp-content/uploads/2016/03/img2.jpg"></article>
		</section>
		<section class="conteudo-inferior">
			<article class="artigo3"><img src="http://localhost:8080/wordpress/wp-content/uploads/2016/03/img3.jpg"></article>
			<article class="artigo4"><img src="http://localhost:8080/wordpress/wp-content/uploads/2016/03/img4.jpg"></article>
		</section>

</main>


<?php get_footer(); ?>