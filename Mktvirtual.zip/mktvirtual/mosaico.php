<!--Mosaico 1 -->

<?php
if ( have_posts() ) {
	query_posts("&category_name=destaques&offset=0&showposts=1");
	while ( have_posts() ) {
		the_post(); ?>

					<div id="mosaico1">
							<a href="<?php echo get_permalink(); ?>"><?php the_post_thumbnail('mosaico-grande');?></a>
						
						<div id="mosaico1_bloco">
							<div id="mosaico1_title">SIT AMET
								<div class="traco"></div>
								<div id="mosaico1_texto"><?php the_title();?></div>
							</div>
						</div>
					</div>
		<?php } // end while
} // end if
?>


<!--Mosaico 2 -->
<?php
if ( have_posts() ) {
	query_posts("&category_name=destaques&offset=2&showposts=1");
	while ( have_posts() ) {
		the_post(); ?>

								<div id="mosaico2">
									<a href="<?php echo get_permalink(); ?>"><?php the_post_thumbnail('mosaico-medium');?></a>
									
									<div id="mosaico2_bloco">
										<div id="mosaico2_title">IPSUM DOLOR
											<div class="traco"></div>
											<div id="mosaico2_texto"><?php the_title();?></div>
										</div>
									</div>
								</div>
		<?php } // end while
} // end if
?>

<!--Mosaico 3 -->
<?php
if ( have_posts() ) {
	query_posts("&category_name=destaques&offset=3&showposts=1");
	while ( have_posts() ) {
		the_post(); ?>


							<div id="mosaico3">
								<a href="<?php echo get_permalink(); ?>"><?php the_post_thumbnail('mosaico-medium');?></a>
								
								<div id="mosaico3_bloco">
									<div id="mosaico3_title">IPSUM DOLOR
										<div class="traco"></div>
										<div id="mosaico3_texto"><?php the_title();?></div>
									</div>
								</div>
							</div>
		<?php } // end while
} // end if
?>

<!--Mosaico 4 -->
<?php
if ( have_posts() ) {
	query_posts("&category_name=destaques&offset=1&showposts=1");
	while ( have_posts() ) {
		the_post(); ?>

<div id="mosaico4">
	<a href="<?php echo get_permalink(); ?>"><?php the_post_thumbnail('mosaico-grande');?></a>
	
	<div id="mosaico4_bloco">
		<div id="mosaico4_title">SIT AMET
			<div class="traco"></div>
			<div id="mosaico4_texto"><?php the_title();?></div>
		</div>
	</div>
</div>
		<?php } // end while
} // end if
?>

<div class="clear"></div>