<!DOCTYPE html>
<html <?php language_attributes ()?>>
<head>
<meta charset="<?php bloginfo('charset')?>"/>
	<link rel="shortcut icon" href="<?php bloginfo('template_url') ?>/imagens/icon-mkt.png" type="image/x-icon" />
	<title><?php wp_title('-',true,'right'); bloginfo()?></title>
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url') ?>/style.css">
	<?php wp_head(); ?>
</head>

<body>

<header>

<div id="topo">
<!--Logo -->
	<div id="logo">
		<a href="<?php bloginfo('home');?>"><img src="<?php bloginfo('template_url') ?>/imagens/logo.png" alt="Logo do Site Mkt Virtual" title="Mkt Virtual" /></a>
	</div>


<!--Menu -->
	<nav>
		<ul>
			<li><a href="<?php bloginfo('home');?>">LOREM</a></li>
			<li><a href="">IPSUM DOLOR</a></li>
			<li><a href="">SIT AMET</a></li>
			<li><a href="">MAURIS</a></li>
			<li><a href="">NEQUE NULLA</a></li>
			<li><a href="">BIBENDUM</a></li>
			<li><a href="">CONGUEDON MAURIS</a></li>

		</ul>
	</nav>
</div>

</header>