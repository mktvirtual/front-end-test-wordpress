<!--Ultimas -->

<div id="title_list">ÚLTIMAS</div>
<?php
if ( have_posts() ) {
	query_posts("&orderby=time&order=desc&showposts=4&category_name=Ultimas");
	while ( have_posts() ) {
		the_post(); ?>

<div id="item_list">
	
	<a href="<?php echo get_permalink(); ?>"><?php the_post_thumbnail('listas');?></a>
	<div id="item_titulo">SIT AMET</div>
	<div id="item_texto">LOREM IPSUM DOLOR SIT AMET, CONSECTETUER ADIPISCING ELIT</div>
	<div id="item_data"><?php the_time('j \d\e F \d\e Y') ?></div>
</div>

	<?php } // end while
} // end if
?>


<!--Lorem -->


<div id="title_list">LOREM</div>

<?php
if ( have_posts() ) {
	query_posts("&showposts=4&category_name=Lorem");
	while ( have_posts() ) {
		the_post(); ?>
		

<div id="item_list">
	
	<a href="<?php echo get_permalink(); ?>"><?php the_post_thumbnail('listas'); ?></a>
	<div id="item_texto"><?php the_title();?></div>
	<div id="item_data"><?php the_time('j \d\e F \d\e Y') ?></div>
</div>

	<?php } // end while
} // end if
?>



<!--IMPSUM -->

<div id="title_list">IMPSUM</div>

<?php
if ( have_posts() ) {
	query_posts("&showposts=4&category_name=Ipsum");
	while ( have_posts() ) {
		the_post(); ?>

<div id="item_list">
	
	<a href="<?php echo get_permalink(); ?>"><?php the_post_thumbnail('listas');?></a>
	<div id="item_texto"><?php the_title();?></div>
	<div id="item_data"><?php the_time('j \d\e F \d\e Y') ?></div>
</div>

	<?php } // end while
} // end if
?>



<div class="clear"></div>