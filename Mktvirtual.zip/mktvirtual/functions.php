<?php 

/*WIDGET*/

if (function_exists('register_sidebar'))
{
	
	register_sidebar(array(

		));
}

/*Imagem destacada */

add_theme_support('post-thumbnails');


add_image_size( "mosaico-grande", 590, 350, true );/*Imagem de destaqueda mosaico 1 e 4 */
add_image_size( "mosaico-medium", 350, 350, true );/*Imagem de destaque mosaico 2 e 3 */
add_image_size( "listas", 230, 190, true );/*Imagem de destaque  das listas */
