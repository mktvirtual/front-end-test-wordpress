<?php get_header(); ?><!--Parte Responsavel Pelo Topo,Menu -->

<section>
<?php include "mosaico.php"; ?><!--Parte Responsavel Pelo Mosaico Principal de Destaques -->
<?php include "article.php"; ?><!--Parte Responsavel Pelas Listas de Ultimas,Lorem , Impsum -->
</section>


<?php get_footer(); ?><!--Parte Responsavel Pelo Rodapé-->
<?php wp_footer(); ?>

</body>
</html>