
<footer>
	<div id="footer_bloco">

		<div id="rede_sociais">
			<img src="<?php bloginfo('template_url')?>/imagens/icon-Facebook.png">
			<img src="<?php bloginfo('template_url')?>/imagens/icon-Twitter.png">
			<img src="<?php bloginfo('template_url')?>/imagens/icon-Instagram.png">
			<img src="<?php bloginfo('template_url')?>/imagens/icon-Youtube.png">
			<img src="<?php bloginfo('template_url')?>/imagens/icon-Feeds.png">
		</div>

		<div id="assinatura">
			<img src="<?php bloginfo('template_url')?>/imagens/icon-Assinatura.png">
		</div>


</div>
</footer>

</body>
</html>
