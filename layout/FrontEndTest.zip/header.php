<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8" />
<title>FRONTENDTEST</title>
<style type="text/css">
td img {display: block;}
</style>
<script type="text/javascript">
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
</script>
</head>
<body onLoad="MM_preloadImages('images/topo_r2_c4_s2.png','images/topo_r2_c6_s2.png','images/topo_r2_c8_s2.png','images/topo_r2_c10_s2.png','images/topo_r2_c12_s2.png','images/topo_r2_c14_s2.png','images/topo_r3_c2_s2.png')">
<div id="corpo">
	<div id="header" align="center">
<h1><table style="display: inline-table;" border="0" cellpadding="0" cellspacing="0" width="1100">
  <!-- fwtable fwsrc="topo.fw.png" fwpage="Page 1" fwbase="cabecalho.png" fwstyle="Dreamweaver" fwdocid = "889391569" fwnested="0" -->
  <tr>
    <td><img src="images/spacer.gif" width="35" height="1" alt="" /></td>
    <td><img src="images/spacer.gif" width="68" height="1" alt="" /></td>
    <td><img src="images/spacer.gif" width="38" height="1" alt="" /></td>
    <td><img src="images/spacer.gif" width="139" height="1" alt="" /></td>
    <td><img src="images/spacer.gif" width="33" height="1" alt="" /></td>
    <td><img src="images/spacer.gif" width="93" height="1" alt="" /></td>
    <td><img src="images/spacer.gif" width="35" height="1" alt="" /></td>
    <td><img src="images/spacer.gif" width="73" height="1" alt="" /></td>
    <td><img src="images/spacer.gif" width="36" height="1" alt="" /></td>
    <td><img src="images/spacer.gif" width="143" height="1" alt="" /></td>
    <td><img src="images/spacer.gif" width="27" height="1" alt="" /></td>
    <td><img src="images/spacer.gif" width="102" height="1" alt="" /></td>
    <td><img src="images/spacer.gif" width="29" height="1" alt="" /></td>
    <td><img src="images/spacer.gif" width="231" height="1" alt="" /></td>
    <td><img src="images/spacer.gif" width="18" height="1" alt="" /></td>
    <td><img src="images/spacer.gif" width="1" height="1" alt="" /></td>
  </tr>
  <tr>
    <td colspan="15"><img name="cabecalho_r1_c1" src="images/cabecalho_r1_c1.png" width="1100" height="74" id="cabecalho_r1_c1" alt="" /></td>
    <td><img src="images/spacer.gif" width="1" height="74" alt="" /></td>
  </tr>
  <tr>
    <td colspan="3"><img name="cabecalho_r2_c1" src="images/cabecalho_r2_c1.png" width="141" height="1" id="cabecalho_r2_c1" alt="" /></td>
    <td rowspan="2"><a href="javascript:;" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('cabecalho_r2_c4','','images/cabecalho_r2_c4_s2.png',1);"><img name="cabecalho_r2_c4" src="images/cabecalho_r2_c4.png" width="139" height="35" id="cabecalho_r2_c4" alt="" /></a></td>
    <td rowspan="2"><img name="cabecalho_r2_c5" src="images/cabecalho_r2_c5.png" width="33" height="35" id="cabecalho_r2_c5" alt="" /></td>
    <td rowspan="2"><a href="javascript:;" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('cabecalho_r2_c6','','images/cabecalho_r2_c6_s2.png',1);"><img name="cabecalho_r2_c6" src="images/cabecalho_r2_c6.png" width="93" height="35" id="cabecalho_r2_c6" alt="" /></a></td>
    <td rowspan="2"><img name="cabecalho_r2_c7" src="images/cabecalho_r2_c7.png" width="35" height="35" id="cabecalho_r2_c7" alt="" /></td>
    <td rowspan="2"><a href="javascript:;" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('cabecalho_r2_c8','','images/cabecalho_r2_c8_s2.png',1);"><img name="cabecalho_r2_c8" src="images/cabecalho_r2_c8.png" width="73" height="35" id="cabecalho_r2_c8" alt="" /></a></td>
    <td rowspan="2"><img name="cabecalho_r2_c9" src="images/cabecalho_r2_c9.png" width="36" height="35" id="cabecalho_r2_c9" alt="" /></td>
    <td rowspan="2"><a href="javascript:;" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('cabecalho_r2_c10','','images/cabecalho_r2_c10_s2.png',1);"><img name="cabecalho_r2_c10" src="images/cabecalho_r2_c10.png" width="143" height="35" id="cabecalho_r2_c10" alt="" /></a></td>
    <td rowspan="2"><img name="cabecalho_r2_c11" src="images/cabecalho_r2_c11.png" width="27" height="35" id="cabecalho_r2_c11" alt="" /></td>
    <td rowspan="2"><a href="javascript:;" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('cabecalho_r2_c12','','images/cabecalho_r2_c12_s2.png',1);"><img name="cabecalho_r2_c12" src="images/cabecalho_r2_c12.png" width="102" height="35" id="cabecalho_r2_c12" alt="" /></a></td>
    <td rowspan="2"><img name="cabecalho_r2_c13" src="images/cabecalho_r2_c13.png" width="29" height="35" id="cabecalho_r2_c13" alt="" /></td>
    <td rowspan="2"><a href="javascript:;" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('cabecalho_r2_c14','','images/cabecalho_r2_c14_s2.png',1);"><img name="cabecalho_r2_c14" src="images/cabecalho_r2_c14.png" width="231" height="35" id="cabecalho_r2_c14" alt="" /></a></td>
    <td rowspan="2"><img name="cabecalho_r2_c15" src="images/cabecalho_r2_c15.png" width="18" height="35" id="cabecalho_r2_c15" alt="" /></td>
    <td><img src="images/spacer.gif" width="1" height="1" alt="" /></td>
  </tr>
  <tr>
    <td><img name="cabecalho_r3_c1" src="images/cabecalho_r3_c1.png" width="35" height="34" id="cabecalho_r3_c1" alt="" /></td>
    <td><a href="javascript:;" onmouseout="MM_swapImgRestore();" onmouseover="MM_swapImage('cabecalho_r3_c2','','images/cabecalho_r3_c2_s2.png',1);"><img name="cabecalho_r3_c2" src="images/cabecalho_r3_c2.png" width="68" height="34" id="cabecalho_r3_c2" alt="" /></a></td>
    <td><img name="cabecalho_r3_c3" src="images/cabecalho_r3_c3.png" width="38" height="34" id="cabecalho_r3_c3" alt="" /></td>
    <td><img src="images/spacer.gif" width="1" height="34" alt="" /></td>
  </tr>
</table></h1>
<div id="mosaico" align="center">
<table align="center">
<tr>
<td>
  <div id="foto">
    <p class="titulo1">SIT AMET</p>
    <p class="texto1"><b>LOREM IPSUM DOLOR SIT AMET,<br />CONSEXTETUER ADIPISCING ELIT</b></p>
    <img src="transp1.png" width="355" height="92" class= "icone1" />
    <img src="imagens/img01.png" width="523" height="331">
    </div>
    </td>
    <td>
	<p class="titulo2">IPSUM DOLOR</p>
    <p class="texto2"><b>DONEC MAURIS NEQUE,<br /> 
      VENENATIS A</b></p>
    <img src="transp1.png" width="90" height="90" class="icone2" />
    <img src="imagens/img02.png" width="331" height="331">
	</td>
	</tr>
    </table>
    <table>
    <tr>
    <td>
	<p class="titulo3">IPSUM DOLOR</p>
    <p class="texto3"><b>DONEC MAURIS NEQUE,<br /> 
      VENENATIS A</b></p>
    <img src="transp1.png" width="90" height="90" class="icone3" />
    <img src="imagens/img03.png" width="402" height="268">
	</td>
    <td>
    <div id="foto">
    <p class="titulo4">SIT AMET</p>
    <p class="texto4"><b>LOREM IPSUM DOLOR SIT AMET,<br />
      CONSEXTETUER ADIPISCING ELIT</b></p>
    <img src="transp1.png" width="355" height="92" class= "icone4" />
    <img src="imagens/img04.png" width="400" height="268">
    </div>    
    </td>  
    </tr> 
    </table>
</div>
</div>
<div class="ultimas"> 
    <h2>ÚLTIMAS</h2>
    <table>
    <tr>
    <td>
    <img src="imagens/img05.png" width="230" height="210">
    <p1>SIT AMET</p1>
    <p>LOREM IPSUM DOLOR SIT <BR /> AMET, CONSECTETUER<BR /> ADIPISCING ELIT</p>
    <div class="data">29 de janeiro de 2014</div>
    </td>
    <td>
    <img src="imagens/img06.png" width="220" height="210">
    <p1>SIT AMET</p1>
    <p>LOREM IPSUM DOLOR SIT <BR /> AMET, CONSECTETUER<BR /> ADIPISCING ELIT</p>
    <div class="data">29 de janeiro de 2014</div>
    </td>
    <td>
    <img src="imagens/img07.png" width="207" height="210">
    <p1>SIT AMET</p1>
    <p>LOREM IPSUM DOLOR SIT <BR /> AMET, CONSECTETUER<BR /> ADIPISCING ELIT</p>
    <div class="data">29 de janeiro de 2014</div>
    </td> 
    <td>
    <img src="imagens/img08.png" width="219" height="209">
    <p1>SIT AMET</p1>
    <p>LOREM IPSUM DOLOR SIT <BR /> AMET, CONSECTETUER<BR /> ADIPISCING ELIT</p>
    <div class="data">29 de janeiro de 2014</div>
    </td>  
    </tr>
    </table>
    
    
    <h2>LOREM</h2>   
    <table>
    <tr>
    <td>
    <img src="imagens/img09.png" width="225" height="209">
    <p>LOREM IPSUM DOLOR SIT <BR /> 
      AMET, CONSECTETUER<BR /> ADIPISCING ELIT</p>
    <div class="data">29 de janeiro de 2014</div>
    </td>
    <td>
    <img src="imagens/img10.png" width="220" height="210">
    <p>LOREM IPSUM DOLOR SIT <BR /> 
      AMET, CONSECTETUER<BR /> ADIPISCING ELIT</p>
    <div class="data">29 de janeiro de 2014</div>
    </td>
    <td>
    <img src="imagens/img11.png" width="225" height="210">
    <p>LOREM IPSUM DOLOR SIT <BR /> 
      AMET, CONSECTETUER<BR /> ADIPISCING ELIT</p>
    <div class="data">29 de janeiro de 2014</div>
    </td> 
    <td>
    <img src="imagens/img12.png" width="223" height="210">
    <p>LOREM IPSUM DOLOR SIT <BR /> 
      AMET, CONSECTETUER<BR /> ADIPISCING ELIT</p>
    <div class="data">29 de janeiro de 2014</div>
    </td>  
    </tr>
    </table>
    
    
    <h2>IPSUM</h2>   
    <table>
    <tr>
    <td>
    <img src="imagens/img13.png" width="259" height="210">
    <p>LOREM IPSUM DOLOR SIT <BR /> 
      AMET, CONSECTETUER<BR /> ADIPISCING ELIT</p>
    <div class="data">29 de janeiro de 2014</div>
    </td>
    <td>
    <img src="imagens/img14.png" width="221" height="210">
    <p>LOREM IPSUM DOLOR SIT <BR /> 
      AMET, CONSECTETUER<BR /> ADIPISCING ELIT</p>
    <div class="data">29 de janeiro de 2014</div>
    </td>
    <td>
    <img src="imagens/img15.png" width="225" height="210">
    <p>LOREM IPSUM DOLOR SIT <BR /> 
      AMET, CONSECTETUER<BR /> ADIPISCING ELIT</p>
    <div class="data">29 de janeiro de 2014</div>
    </td> 
    <td>
    <img src="imagens/img16.png" width="213" height="210">
    <p>LOREM IPSUM DOLOR SIT <BR /> 
      AMET, CONSECTETUER<BR /> ADIPISCING ELIT</p>
    <div class="data">29 de janeiro de 2014</div>
    </td>  
    </tr>
    </table>
</div> 

    <div class="footer" align="center">
        <p><img name="rodape" src="images/rodape.png" width="1100" height="57" id="rodape" usemap="#m_rodape" alt="" />
<map name="m_rodape" id="m_rodape">
  <area shape="rect" coords="203,18,226,41" href="http://rss.com" alt="" />
  <area shape="rect" coords="163,17,186,40" href="http://youtube.com" alt="" />
  <area shape="rect" coords="122,17,145,40" href="http://instagram.com" alt="" />
  <area shape="rect" coords="80,17,104,40" href="http://twitter.com" alt="" />
  <area shape="rect" coords="48,17,63,40" href="http://facebook.com" alt="" />
</map>
</p>

    </div>
 
</div>
 
</body>
</html>   